				<h3><b><center>No. Antrian Sekarang</center></b></h3>
				<?php foreach($last as $d){ ?>
					<h4 style="margin-left:20px; font-size:40px;" ><?= $d->group.' = '.$d->kode.$d->no?></h4>
				<?php } ?>
				
				<form role="form" method="post" >
					  <div class="form-group">
						<label>Cari menggunkana Nama / NIK:</label>
						<input name="s" type="text" class="form-control radius-3 margin-b-10" id="pwd">
					  </div>						  			  					 					  
					  <div class="form-group">
						<label>Antrian Untuk:</label>
						<select name="group" >
							<option value="">Semua</option>
							<?php foreach($group as $d){ ?>
							<option value="<?=$d->idgroup?>"><?=$d->group?></option>
							<?php } ?>
						</select>						
					  </div>								  
                       <button type="submit" name="tambah" value="submit" class="btn-green-brd btn-base-animate-to-top btn-base-sm radius-7">Cari
                        <span class="btn-base-element-md"><i class="btn-base-element-icon fa fa-users"></i></span>
					   </button>					 
				</form>
								
				<div style="font-size:14px;">
					<table style="padding:3px; width:800px;" border="none" >
						<thead>
							<tr style="font-size:14px; border-bottom:solid #000 2px;">
								<th width="15%">No. Antrian</th>
								<th width="30%">Nama</th>
								<th>NIK</th>
								<th>Antrian Untuk</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($antrian as $d) { ?>
							<tr style="font-size:12px; border-bottom:solid #000 2px;">
								<td><?= $d->kode.$d->no?></td>
								<td><?= $d->nama?></td>
								<td><?= $d->nik?></td>
								<td><?= $d->group?></td>
								<td>
									<?php  
										if($d->status == 0){
											echo 'Dalam Antrian';
										} else if($d->status == 1){
											echo 'Saatnya ke  '.$d->loket;
										}
									?>
								</td>
							</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>