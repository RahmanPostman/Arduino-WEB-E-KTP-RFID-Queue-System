<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Group extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('antrian_m');        
		$this->load->model('auth_m');        
		$this->load->model('user_m');        		
	}

	public function index()
	{
		$data=array();
		if(isset($_GET['alert'])){$data['alert']=$_GET['alert'];}
		else{$data['alert']='';}		
		$data['title']='Group';
		$data['user'] = $this->auth_m->get_admin_by_id($this->session->userdata('antrian_admin'));		
		$data['data']=$this->antrian_m->get_group();		
		$this->load->view('group_v', $data);
	}

	public function add()
	{
		$data=array();
		$data['user'] = $this->auth_m->get_admin_by_id($this->session->userdata('antrian_admin'));		
		$data['alert']='';
		$data['title']='Tambah Group';
		$data['error']='';
		
		$rgb['green'] = '#00a65a';
		$rgb['aqua'] =  '#00c0ef';		
		$rgb['primary'] =  '#303641';
		$rgb['orange'] =  '#ffa812;';
		$btn['green'] = 'success';
		$btn['aqua'] = 'info';		
		$btn['primary'] = 'primary';
		$btn['orange'] = 'orange';
		
		if($this->input->post('simpan')){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('group', 'Group', 'required|trim|xss_clean|is_unique[groups.group]');			
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			} else{
				$input=array(
					'group' => $this->input->post('group'),					
					'kode' => $this->input->post('kode'),
					'btn' => $btn[$this->input->post('warna')],					
					'rgb' => $rgb[$this->input->post('warna')],					
					'warna' => $this->input->post('warna')
				);
				$insert=$this->antrian_m->insert('groups', $input);				
				if($insert)	redirect(base_url().'group/?alert=success') ; 			
				else redirect(base_url().'group/?alert=failed') ; 			
			}			
		}
		$data['warna']=array('green','aqua','primary','orange');
		$data['group']=$this->antrian_m->get_group();
		$this->load->view('group_add_v', $data);
	}

	public function edit($id='')
	{
		$data=array();
		$data['user'] = $this->auth_m->get_admin_by_id($this->session->userdata('antrian_admin'));		
		$data['alert']='';
		$data['title']='Edit Group';
		$data['error']='';
		$rgb['green'] = '#00a65a';
		$rgb['aqua'] =  '#00c0ef';		
		$rgb['primary'] =  '#303641';
		$rgb['orange'] =  '#ffa812;';
		$btn['green'] = 'success';
		$btn['aqua'] = 'info';		
		$btn['primary'] = 'primary';
		$btn['orange'] = 'orange';
		
		if($this->input->post('simpan')){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('group', 'Group', 'required');
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			} else{ 
				$input=array(
					'group' => $this->input->post('group'),					
					'kode' => $this->input->post('kode'),
					'btn' => $btn[$this->input->post('warna')],					
					'rgb' => $rgb[$this->input->post('warna')],					
					'warna' => $this->input->post('warna')
				);

				$insert=$this->antrian_m->update('groups', 'idgroup', $id, $input);				
				if($insert)	redirect(base_url().'group/?alert=success') ; 			
				else redirect(base_url().'group/?alert=failed') ; 			
			}			
		}		
		$data['data']=$this->antrian_m->get_single('groups', 'idgroup', $id);
		$data['group']=$this->antrian_m->get_group();
		$data['warna']=array('green','aqua','primary','orange');
		$this->load->view('group_edit_v', $data);
	}

	public function delete($id=''){	
		$data = $this->antrian_m->get_single('groups', 'idgroup', $id);
		if(!$this->antrian_m->cek_hapus_g($data->idgroup)){
			$del=$this->antrian_m->delete('groups', 'idgroup', $id);
			if($del){
				redirect(base_url().'group/?alert=success') ; 			
			} 
		}
		redirect(base_url().'group/?alert=failed') ; 			
	}	
}

/* End of file  */
/* Location: ./application/controllers/ */