<?php include 'header.php'; ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Group</h1>
            <ol class="breadcrumb">
              <li><a href="<?=base_url();?>dashboard">Dashboard</a></li>
              <li><a href="<?=base_url();?>group">Group</a></li>
              <li class="active">Edit</li>
            </ol>
            <?php if($alert=='success'){ ?>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Success
            </div>
            <?php } ?>

            <?php if($alert=='failed'){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Failed
            </div>
            <?php } ?>
			
			<?php if($error!=''){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?=$error;?>
            </div>
            <?php } ?>
			
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-12">
            <form class="form-horizontal" method="post" action="<?=base_url();?>Group/edit/<?=$data->idgroup;?>">              
              <div class="form-group">
                <label for="loket" class="col-lg-2 control-label">Nama Group</label>
                <div class="col-lg-4">
                  <input name="group" value="<?= $data->group?>" type="text" class="form-control" id="Group" placeholder="Masukkan Group" required>
                </div>
              </div>
			  <div class="form-group">
                <label for="loket" class="col-lg-2 control-label">Kode Group</label>
                <div class="col-lg-4">
                  <input name="kode" value="<?= $data->kode?>" type="text" class="form-control" id="Group" placeholder="Masukkan Group" required>
                </div>
              </div>
			  
			  <div  class="form-group">
				<label class="col-lg-2 control-label">Warna : </label>
				<div class="col-lg-4">
					<select name ="warna" class="form-control radius-3 margin-b-10"  required>
						<?php foreach($warna as $d){ ?>
						<option <?=($data->warna==$d)?'selected':'';?> value="<?= $d?>" > <?= $d ?> </option>
						<?php } ?>
					</select>
				</div>
			  </div>			  			  
              <div class="form-group">
                <div class="col-lg-2"></div>
                <div class="col-lg-4">
                  <button class="btn btn-primary pull-right" type="submit" name="simpan" value=1>Simpan</button>                  
                </div>
              </div>
            </form>            
          </div>
        </div><!-- /.row -->

      </div><!-- /#page-wrapper -->   
<?php include 'footer.php'; ?>