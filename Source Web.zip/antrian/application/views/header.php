<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?=$title;?> - Antrian Online Administor/Loket</title>
    <!--<link rel="shortcut icon" href="<?=base_url();?>asset/img/favicon.ico">-->
    <link href="<?=base_url();?>asset/admin/css/bootstrap.css" rel="stylesheet">
    <link href="<?=base_url();?>asset/admin/css/sb-admin.css" rel="stylesheet">
    <link href="<?=base_url();?>asset/admin/css/jquery-ui.css" rel="stylesheet">
    <link rel="stylesheet" href="<?=base_url();?>asset/admin/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=base_url();?>asset/admin/css/morris-0.4.3.min.css">    
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css">	
    <script src="<?=base_url();?>asset/admin/js/jquery-1.10.2.js"></script>
	<style>
		.paginate_button {
			margin-right:3px;
		}
		.paging_full_numbers span{
			margin-left : 5px;
			margin-right : 5px;
		}
    .modal-dialog{
    overflow-y: initial !important
    }
    .modal-body{
        height: 250px;
        overflow-y: auto;
    }
	</style>
  </head>

  <body>

    <div id="wrapper">

      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?=base_url();?>/dashboard"> Antrian | Dashboard Area</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
			<li class="<?=($title=='Dashboard')?'active':''?>"><a href="<?=base_url();?>dashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>						
			<?php if($user->tipe == 1){ ?>			
			<!-- <li class="<?=($title=='Informasi')?'active':''?>"><a href="<?=base_url();?>info"><i class="fa fa-info"></i> Informasi</a></li> -->
			<li <?=($title=='Group' or $title=='Tambah Group' or $title=='Edit Group' )?'class="active"':''?>><a href="<?=base_url();?>group"><i class="fa fa-home"></i> Group</a></li>
			<li <?=($title=='Loket' or $title=='Tambah Loket' or $title=='Edit Loket' )?'class="active"':''?>><a href="<?=base_url();?>loket"><i class="fa fa-book"></i> Loket</a></li>					
			<li <?=($title=='Petugas Loket' or $title=='Tambah Petugas  Loket' or $title=='Edit Petugas Loket' )?'class="active"':''?>><a href="<?=base_url();?>petugasloket"><i class="fa fa-user"></i> Petugas Loket</a></li>
			<!--<li <?=($title=='Administrator' or $title=='Tambah Administrator' or $title=='Edit Administrator' )?'class="active"':''?>><a href="<?=base_url();?>administrator"><i class="fa fa-group"></i> Administrator</a></li>-->					                
			<?php } ?>
			<?php if($user->tipe == 2){ ?>			
			<li <?=($title=='Antrian' )?'class="active"':''?>><a href="<?=base_url();?>loketantrian"><i class="fa fa-book"></i> Antrian Loket : <?= $user->loket?></a></li>					
			<?php } ?>
         </ul>
          <ul class="nav navbar-nav navbar-right navbar-user">
			<!---<li class="dropdown alerts-dropdown">
              <a id="stok"  class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i>  Print Request <span id="count-notifikasi-stok" class="badge"></span> <b class="caret"></b></a>
              <ul id="stok-notif" class="dropdown-menu">
                <div id="loading" style="display:none;"><br>Loading...<img src="<?=base_url();?>asset/admin/img/loading.gif"></div>
              </ul>
            </li>-->
			<li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?=$user->nama;?> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <!-- <li><a href="<?=base_url();?>user/myprofile"><i class="fa fa-user"></i> Profile</a></li>
                <li><a href="<?=base_url();?>user/setting"><i class="fa fa-gear"></i> Settings</a></li> -->
                <li class="divider"></li>
                <li><a href="<?= base_url()?>user/logout"><i class="fa fa-power-off"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>
