    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="<?=base_url();?>asset/admin/js/bootstrap.js"></script>
    <script src="<?=base_url();?>asset/admin/js/jquery-ui.min.js"></script>
    <script src="<?=base_url();?>asset/admin/js/jquery.dataTables.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>   
	<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>   
	<script src="https://cdn.datatables.net/select/1.2.0/js/dataTables.select.min.js "></script>   
    <script type="text/javascript">
var base_url = '<?=base_url();?>';
var admin_url = '<?=admin_url();?>';
</script>
<script type="text/javascript">
$('.btn-danger').click(function(){
  return confirm('Are you sure delete this item?');
});
$( "#date_start" ).datepicker({
			changeMonth: true,
			changeYear: true,
			yearRange:'-90:+0',
			dateFormat: 'dd-mm-yy'
		  });
		  $( "#dari_tanggal" ).datepicker({
			changeMonth: true,
			changeYear: true,
			yearRange:'-90:+0',
			dateFormat: 'dd-mm-yy'
		  });
		  $( "#sampai_tanggal" ).datepicker({
			changeMonth: true,
			changeYear: true,
			yearRange:'-90:+0',
			dateFormat: 'dd-mm-yy'
		  });
</script>
  </body>
</html>