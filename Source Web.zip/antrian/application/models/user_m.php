<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class user_m extends My_Model{
	protected $table = "tbl_user";

	public function __construct(){
		parent ::__construct();
	}

	public function get_user_by_id($id){
		$sql = "SELECT * FROM user a join loket b on a.idloket = b.idloket WHERE id=$id";
		$b   = $this->db->query($sql);
		$row = $b->row();
		$b->free_result();
		return $row;
	}

	public function get_pengurus_search($s='',$limit,$offset){
		$sql = "SELECT * from  users where pengurus=1 AND (nik like '%$s%' or nama like '%$s%') ORDER BY noanggota ASC LIMIT " . $offset . ", " . $limit . "";
		$q = $this->db->query($sql);
		$data = $q->result();
		$q->free_result();
		return $data;
	}
	
	public function get_user_by_email($email){
		$sql = "SELECT * FROM user WHERE email = '$email'";
		$b   = $this->db->query($sql);
		$row = $b->row();
		$b->free_result();
		return $row;
	}

	public function cek_old_pass($id,$pass){
		$b = $this->db->query("SELECT * FROM user WHERE id='$id' AND password='$pass'");
		if($b->num_rows == 0){
			return false;
		} else {
			return true;
		}
	}

	function get_news($tgl){
		$sql = "SELECT * FROM news WHERE tanggal>'$tgl' ORDER BY id_news DESC";
		$b = $this->db->query($sql);
		$row = $b->result();
		$b->free_result();
		return $row;
	}

	function get_user_login($_username, $_password) {
        $sql = "select * from user
            where id_group = 1 AND (username='" . $_username . "')
            AND password = '" . $_password . "' AND status = 1";
        $query = $this->db->query($sql);
		if ($query->num_rows() > 0) {
            return $query->row()->id;
        }
    }

	function view_all_admin($limit='', $offset=''){
		$sql=	"select * from admin  ORDER BY id DESC limit ".$offset.",".$limit."";
		$q=$this->db->query($sql);
		$data = $q->result();
		$q->free_result();
		return $data;
	}

    function view_all_member($limit='', $offset=''){
		$sql=	"select * from users ORDER BY id DESC limit ".$offset.",".$limit."";
		$q=$this->db->query($sql);
		$data = $q->result();
		$q->free_result();
		return $data;
	}

	function count_all_member_search($s=''){
            $sql = "select count(id) as jumlah from  users where (nik like '%$s%' or nama like '%$s%')";
            $q = $this->db->query($sql);
            $data = $q->row();
            $q->free_result();
            return $data->jumlah;
	}

	function get_member_by_search($s='',$limit,$offset){
            $sql = "select * from  users where (nik like '%$s%' or nama like '%$s%') ORDER BY noanggota ASC LIMIT " . $offset . ", " . $limit . "";
            $q = $this->db->query($sql);
            $data = $q->result();
            $q->free_result();
            return $data;
	}

	function count_all_member_search_lap($s='',$idp,$idk){
            $sql = "select count(id) as jumlah from  users where verified=1 and (nik like '%$s%' or nama like '%$s%')";
			if(!empty($idp))
				$sql.= " AND provinsi = $idp ";
			if(!empty($idk))
				$sql.= " AND kabupaten = $idk ";
            $q = $this->db->query($sql);
            $data = $q->row();
            $q->free_result();
            return $data->jumlah;
	}

	function get_member_by_search_lap($s='',$idp,$idk,$limit,$offset){
            $sql = "select * from  users where verified=1 and  (nik like '%$s%' or nama like '%$s%')";
            if(!empty($idp))
				$sql.= " AND provinsi = $idp ";
			if(!empty($idk))
				$sql.= " AND kabupaten = $idk ";
			$sql.= " ORDER BY id DESC LIMIT " . $offset . ", " . $limit . "";
			$q = $this->db->query($sql);
            $data = $q->result();
            $q->free_result();
            return $data;
	}

	function get_member_by_search_lap_all($s='',$idp,$idk){
            $sql = "select * from  users a join provinces b on a.provinsi = b.id join regencies c on a.kabupaten = c.id where verified=1 and  (nik like '%$s%' or nama like '%$s%')";
            if(!empty($idp))
				$sql.= " AND provinsi = $idp ";
			if(!empty($idk))
				$sql.= " AND kabupaten = $idk ";
			$q = $this->db->query($sql);
            $data = $q->result();
            $q->free_result();
            return $data;
	}

	function get_member_bann_by_search_lap_all($s='',$idp,$idk){
            $sql = "select * from  users a join provinces b on a.provinsi = b.id join regencies c on a.kabupaten = c.id where verified=2 and  (nik like '%$s%' or nama like '%$s%')";
            if(!empty($idp))
				$sql.= " AND provinsi = $idp ";
			if(!empty($idk))
				$sql.= " AND kabupaten = $idk ";
			$q = $this->db->query($sql);
            $data = $q->result();
            $q->free_result();
            return $data;
	}

	function count_all_member(){

    }

	function count_all_admin_search($s=''){
            $sql = "select * from user where tipe = 1 AND ( username LIKE '%%' or nama LIKE '%%')";
            $q = $this->db->query($sql);
            $data = $q->num_rows;
            $q->free_result();
            return $data;
	}

	function get_admin_by_search($s='',$limit,$offset){
            $sql = "select * from user where tipe = 1 ";
			$sql.="AND ( username LIKE '%$s%' or nama LIKE '%$s%')";
            $sql .= " ORDER BY id desc LIMIT " . $offset . ", " . $limit . "";
            $q = $this->db->query($sql);
            $data = $q->result();
            $q->free_result();
            return $data;
	}
	
	function count_all_petugas_search($s=''){
            $sql = "select * from user a join loket b on a.idloket = b.idloket where tipe = 2 AND ( username LIKE '%%' or nama LIKE '%%')";
            $q = $this->db->query($sql);
            $data = $q->num_rows;
            $q->free_result();
            return $data;
	}

	function get_petugas_by_search($s='',$limit,$offset){
            $sql = "select * from user a join loket b on a.idloket = b.idloket where tipe = 2 ";
			$sql.="AND ( username LIKE '%$s%' or nama LIKE '%$s%')";
            $sql .= " ORDER BY id desc LIMIT " . $offset . ", " . $limit . "";
            $q = $this->db->query($sql);
            $data = $q->result();
            $q->free_result();
            return $data;
	}

	
	function count_all_admin(){
            $sql = "select count(*) as jumlah from user WHERE id_group = 1";
            $q = $this->db->query($sql);
            $data = $q->row();
            $q->free_result();
            return $data->jumlah;
    }

	function cek_password($id='', $pass=''){
		$sql="SELECT COUNT(*) AS jumlah FROM user WHERE id='".$id."' AND password='".$pass."' ";
		$q=$this->db->query($sql);
		$data = $q->row();
		$q->free_result();
		return $data->jumlah;
	}
	
	public function get_by_id($id){
		$sql = "SELECT * FROM users WHERE id = $id";
		$b   = $this->db->query($sql);
		$row = $b->row();
		$b->free_result();
		return $row;
	}
	

	function get_all_admin(){
		$sql=	"select * from user  ORDER BY id DESC";
		$q=$this->db->query($sql);
		$data = $q->result();
		$q->free_result();
		return $data;
	}
	
}
