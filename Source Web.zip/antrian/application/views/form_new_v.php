			<br/>
			<div class="col-md-12">
				<div class="alert alert-warning"><strong>Mohon Maaf </strong> Data E-KTP anda tidak ditemukan silahkan isi terlebih dahulu form dibawah ini lalu pilih Antria sesuai keperluan anda</div>
			</div>
			<div class="panel panel-primary" data-collapsed="0">
				
					<div class="panel-heading">
						<div class="panel-title">
							<h3>Form Pendaftaran Antrian</h3>
						</div>												
					</div>
					
					<div class="panel-body">
						
						<form role="form" class="form-horizontal form-groups-bordered">
			
							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label">NIK</label>								
								<div class="col-sm-8">
									<input type="text" class="form-control" id="nik" placeholder="NIK" name="nik" >
								</div>
							</div>
							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label">Nama</label>								
								<div class="col-sm-8">
									<input type="text" class="form-control" id="nama" placeholder="Nama" name="nama">
								</div>
							</div>
							<input type="hidden" id="key" placeholder="Nama" name="idk" value="<?= $key?>">
							<div class="form-group">
								<?php foreach($group as $d){ ?>
								<div class="col-sm-3">
									<button type="button"  onclick="daftar(<?= $d->idgroup?>)"  class="btn btn-<?= $d->btn?> btn-lg">Antri ke <?= $d->group?></button>
								</div>
								<?php } ?>
							</div>
						</form>
						
					</div>
				
				</div>