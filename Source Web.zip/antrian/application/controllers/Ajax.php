<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

    function __construct(){
        parent::__construct();        
		$this->load->model('antrian_m');		
    }
   	
	public function last(){
		$id = $this->input->post('id');				
		$ab=$this->antrian_m->get_last_antrian_group($id);	
		if($ab)
			echo $ab->kode.$ab->no;
		else 
			echo '0';
	}
	
	public function new_id(){
		$id = $this->input->post('id');				
		if(!empty($id))
			$id = implode(",",$id);
		else 
			$id = 0;
		$ab=$this->antrian_m->get_new_antrian($id);	
		$d= array();
		foreach($ab as $b){
			$d[] = $b->id;
		}
		echo implode(",",$d);
	}
	
	public function lost_id(){
		$id = $this->input->post('id');		
		if(!empty($id))
			$id = implode(",",$id);
		else 
			$id = 0;
		$ab=$this->antrian_m->get_lost_antrian($id);	
		$d= array();
		foreach($ab as $b){
			$d[] = $b->id;		
		}
		echo implode(",",$d);
	}
	
	public function get($id){		
		$b=$this->antrian_m->get_antrian_id($id);					
		$data['d'] = $b;
		$this->load->view('ajax_table_v', $data);
	}	
	
	public function new_q($id){					
		$data['antrian'] = $this->antrian_m->get_new_antrian_by_id($id);							
		if(!empty($data['antrian']))
			$this->load->view('ajax_new_table_v', $data);		
	}
}

		
		
	