<?php include 'header.php'; ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Member Koperumnas.com</h1>
            <ol class="breadcrumb">
              <li><a href="<?=base_url();?>dashboard">Dashboard</a></li>
              <li class="active">Member</li>
            </ol>
            <?php if($alert=='success'){ ?>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Success
            </div>
            <?php } ?>

            <?php if($alert=='failed'){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Failed
            </div>
            <?php } ?>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-12">
            <div class="search">
              <form method="GET" action="" class="form-inline" role="form">
                <div class="form-group">
                  <input value="<?=$s?>" name="s" type="text" class="form-control" id="" placeholder="Username">
                </div>
                <button type="submit" class="btn btn-primary">Cari</button>&nbsp;&nbsp;&nbsp;<a href="<?=base_url();?>user/add"><button type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Member</button></a>
              </form>
            </div>
            <h3>Member</h3>
            <div class="table-responsive">
              <table class="table table-hover table-striped tablesorter">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Nama</th>
                    <th>NIK</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i=0;foreach ($datas as $data) { $i++;?>
                  <tr class="">
                    <td><?=$i;?></td>
                    <td><?= "[".$data->noanggota."] ".$data->nama;?></td>
                    <td><?=$data->nik;?></td>
                    <td><?=$data->email;?></td>
                    <td><?php
						if($data->verified == 0) echo 'belum terverifikasi';
						else if($data->verified == 1)	 echo 'aktif';
						else if($data->verified == 2)	 echo 'banned';
					?></td>
                    <td>
						<?php if($data->verified == '1'){?>
							<a href="<?=base_url().'user/banned/'.$data->id?>" class="btn btn-warning btn-xs"><i class="fa fa-ban"></i> Banned</a>
						<?php } else if($data->verified == '2'){ ?>
							<a href="<?=base_url().'user/active/'.$data->id?>" class="btn btn-info btn-xs"><i class="fa fa-check"></i> Active</a>
						<?php } ?>
            <button type="button" class="btn btn-xs btn-primary" data-toggle="modal" data-target="#ModalKtp" data-nama="<?=$data->nik?>" data-id="<?=$data->id?>" data-src="<?=$data->foto?>" data-status="<?=$data->uploadKtp?>">KTP</button>
            <div class="dropdown btn btn-xs">
              <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                opsi
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li class="<?=(($data->stat_koordinator == 1)? 'disabled':'')?>"><a href="<?=(($data->stat_koordinator == 1)? '#':base_url().'user/toKoordinator/'.$data->id)?>" class="text-left"><?=(($data->stat_koordinator == 1)? 'Koordinator':'Jadikan koordinator')?></a></li>
                <li class="<?=(($data->pengurus == 1)? 'disabled':'')?>"><a href="<?=(($data->pengurus == 1)? '#':base_url().'user/toPengurus/'.$data->id)?>" class="text-left"><?=(($data->pengurus == 1)? 'Pengurus':'Jadikan Pengurus')?></a></li>
                <li role="separator" class="divider"></li>
                <li><a href="<?=base_url();?>user/edit/<?=$data->id;?>" class="text-left"><i class="fa fa-edit"></i> Edit</a></li>
                <li><a href="<?=base_url();?>user/del/<?=$data->id;?>" class="text-left"><i class="fa fa-trash-o"></i> Hapus</a></li>
              </ul>
            </div>
                    </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <div class="col-md-3">
              Jumlah Member : <?=$jmldata?>
            </div>
            <?=$paginator?>
          </div>
        </div><!-- /.row -->

      </div><!-- /#page-wrapper -->
  <div class="modal fade" id="ModalKtp" tabindex="-1" role="dialog" aria-labelledby="ModalKtpLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="ModalKtpLabel">New message</h4>
      </div>
      <div class="modal-body">
        <img id="foto" src="" alt="" />
      </div>
      <div class="modal-footer">
        <a id="aktifkan" href="#" class="btn btn-success">Aktifkan user</a>
        <a id="reupload" href="#" class="btn btn-warning" name="uploadUlang">Upload Ulang</a>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script>
$('#ModalKtp').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget);
  var namaorang = button.data('nama');
  var srcfoto = button.data('src');
  var idorang = button.data('id');
  var verified = button.data('status');
  var modal = $(this);
  modal.find('.modal-title').text('KTP dengan NIK: ' + namaorang);
  modal.find('#foto').attr('src',srcfoto);
  if (verified == 2) {
    modal.find('#reupload').html('Menunggu Reupload');
  } else {
    modal.find('#reupload').attr('href','<?=base_url().'user/ReuploadKtp/'?>' + idorang);
  }
  modal.find('#aktifkan').attr('href','<?=base_url().'user/aktifmanual/'?>' + idorang);
})
</script>
<?php include 'footer.php'; ?>
