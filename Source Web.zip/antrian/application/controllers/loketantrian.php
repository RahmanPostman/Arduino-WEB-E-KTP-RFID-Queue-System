<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class loketantrian extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('antrian_m');        
		$this->load->model('auth_m');        
		$this->load->model('user_m');        		
	}

	public function index()
	{
		$data=array();
		$data['alert']='';		
		$data['error']='';
		$data['title']='Antrian';
		$data['user'] = $this->auth_m->get_admin_by_id($this->session->userdata('antrian_admin'));						
		$antrianbaru = 0;
		$idloket = $data['user']->idloket;
		$data['message'] = "";
		if($this->input->post('tambah')){						
			$idlama = $this->input->post('idlama');
			if(!empty($idlama)){
				$input=array(					
					'status' => 2
				);
		    	$insert=$this->antrian_m->update('antrian','id',$idlama,$input);		    		
			}
			if(empty($idloket)){
				$data['error'] = 'error';
			}else{				
				$antrianbaru=$this->antrian_m->get_last_antrian_loket($idloket);		    	
				if(empty($antrianbaru))					
					$antrianbaru=$this->antrian_m->get_last_antrian_id($idloket);		    	
				if(!empty($antrianbaru)){
					$input=array(					
						'status' => 1,
						'loket' => $antrianbaru->loket_now 
					);
					$insert=$this->antrian_m->update('antrian','id',$antrianbaru->id,$input);		    		
				} else {
					$data['message'] = 'Tidak Ada Antrian';
				}
				
		    }
		}
		$data['data'] = $antrianbaru;
		$data['idloket'] = $idloket;
		$this->load->view('loket_v', $data);				
	}
	
}

/* End of file  */
/* Location: ./application/controllers/ */