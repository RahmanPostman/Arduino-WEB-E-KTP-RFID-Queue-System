<?php include 'header.php'; ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1><?= $title;?></h1>
            <ol class="breadcrumb">
              <li><a href="<?=base_url();?>">Dashboard</a></li>
              <li><a href="<?=base_url();?>jenis">Loket</a></li>
              <li class="active"><?= $title;?></li>
            </ol>
            <?php if($alert=='success'){ ?>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Berhasil
            </div>
            <?php } ?>

            <?php if($alert=='failed'){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Gagal
            </div>
            <?php } ?>				
			<?php if(!empty($error)){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?= $error;?>
            </div>
            <?php } ?>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-12">
            <form class="form-horizontal" method="post" action="<?=base_url();?>loket/add">              
              <div class="form-group">
                <label for="loket" class="col-lg-2 control-label">Nama Loket</label>
                <div class="col-lg-4">
                  <input name="loket" type="text" class="form-control" id="loket" placeholder="Masukkan Loket" required>
                </div>
              </div>
			  
			  <div  class="form-group">
				<label class="col-lg-2 control-label">Group : </label>
				<div class="col-lg-4">
					<select name ="group" class="form-control radius-3 margin-b-10"  required>
						<?php foreach($group as $d){ ?>
						<option value="<?= $d->idgroup?>" > <?= $d->group ?> </option>
						<?php } ?>
					</select>
				</div>
			  </div>			  			  
              <div class="form-group">
                <div class="col-lg-2"></div>
                <div class="col-lg-4">
                  <button class="btn btn-primary pull-right" type="submit" name="simpan" value=1>Simpan</button>                  
                </div>
              </div>
            </form>            
          </div>
        </div><!-- /.row -->

      </div><!-- /#page-wrapper -->   
<?php include 'footer.php'; ?>