<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Antrian extends CI_Controller {

    function __construct(){
        parent::__construct();        
		$this->load->model('antrian_m');		
    }
   	
	public function index(){
		$id = $this->input->post('group');
		$s = $this->input->post('s');
		$data['antrian'] =$this->antrian_m->get_antrian($s,$id);
		$data['antrian_m'] =$this->antrian_m;
		$data['last'] =$this->antrian_m->get_group();
		$this->load->view('home', $data);
	}
	
	public function tambah(){
		$data = '';
		//if($this->input->post('tambah')){
			$data['active'] = 2;
			$this->load->library('form_validation');
			$this->form_validation->set_rules('nama', 'Nama', 'required');
			$this->form_validation->set_rules('nik', 'NIK', 'required');
			$this->form_validation->set_message('required', '%s tidak boleh kosong');
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			}
		    else{
		    	$user=$this->antrian_m->get_user($this->input->post('nik'));
		    	if(empty($user)){
					$input=array(
						'nik' => $this->input->post('nik'),
						'nama' => $this->input->post('nama'),
						'idktp' => $this->input->post('idk')
					);
		    		$insert=$this->antrian_m->insert('tamu',$input);		    		
		    	}
				$input=array(
					'nik' => $this->input->post('nik'),
					'idgroup' => $this->input->post('group'),
					'no' => $this->antrian_m->getlast($this->input->post('group'))
				);
		    	$insert=$this->antrian_m->insert('antrian',$input);		    		
				$ant = $this->antrian_m->get_antrian_id($insert);					;
				$data = $ant->kode.$ant->no;
		    }
		//}		
		echo $data;
	}
	
	public function loket(){
		$antrianbaru = 0;
		$idloket = $this->input->post('id');
		$data['message'] = "";
		if($this->input->post('tambah')){						
			$idlama = $this->input->post('idlama');
			if(!empty($idlama)){
				$input=array(					
					'status' => 2
				);
		    	$insert=$this->antrian_m->update('antrian','id',$idlama,$input);		    		
			}
			if(empty($idloket)){
				$data['error'] = 'error';
			}else{				
				$antrianbaru=$this->antrian_m->get_last_antrian_loket($idloket);		    	
				if(empty($antrianbaru))
					$antrianbaru=$this->antrian_m->get_last_antrian_id($idloket);		    	
				if(!empty($antrianbaru)){
					$input=array(					
						'status' => 1,
						'loket' => $antrianbaru->loket_now 
					);
					$insert=$this->antrian_m->update('antrian','id',$antrianbaru->id,$input);		    		
				} else {
					$data['message'] = 'Tidak Ada Antrian';
				}
				
		    }
		}
		$data['antrian'] = $antrianbaru;
		$data['idloket'] = $idloket;
		$this->load->view('loket_v', $data);
	}
}

		
		