<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_m');
		$this->load->model('auth_m');
	}


	public function myprofile(){
        if(!$this->session->userdata('koperasi_admin')) redirect(base_url() . "user/login");
		$data=array();
		$data['success']='';
		$data['error']='';
		$data['title']='Profile';
		if($this->input->post('simpan')){
			$input=array(
				'username' => $this->input->post('username'),
				'nama' => $this->input->post('nama'),
				'email' => $this->input->post('email')
			);
			$update=$this->user_m->update('admin', 'id_user', $this->session->userdata('koperasi_admin'), $input);
			// echo $update;exit;
			if($update){$data['success']='success';}else{$data['error']='Failed';}
		}
		$data['data']=$this->user_m->get_single('admin', 'id_user', $this->session->userdata('koperasi_admin'));
		$data['user'] = $this->user_m->get_single('admin', 'id_user', $this->session->userdata('koperasi_admin'));
		$this->load->view('user_profil_v', $data);
	}

	public function aktifmanual($id){
		$this->user_m->get_aktif($id);

		redirect(base_url()."user/member");
	}

	public function setting(){
        if(!$this->session->userdata('koperasi_admin')) redirect(base_url() . "user/login");
		$data=array();
		$data['success']='';
		$data['error']='';
		$data['title']      = 'Setting';
		if($this->input->post('simpan')){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('old_password', 'Old Password', 'required');
			$this->form_validation->set_rules('password', 'New Password', 'required|matches[passconf]|min_length[6]');
			$this->form_validation->set_rules('passconf', 'Konfirmasi password', 'required');
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			}
		    else{
		    	$cek_password=$this->auth_m->cek_password($this->session->userdata('koperasi_admin'), md5($this->input->post('old_password')));
		    	if($cek_password>0){
		    		$ganti=$this->user_m->update('admin', 'id_user', $this->session->userdata('koperasi_admin'), array('password'=>md5($this->input->post('password'))));
		    		if($ganti){$data['success']='Password berhasil diganti.';}else{$data['error']='Failed';}
		    	} else {
		    		$data['error']= 'Password Anda salah';
		    	}
		    }
		}
		$data['user']=$this->user_m->get_single('admin', 'id_user', $this->session->userdata('koperasi_admin'));
		$data['data']=$this->user_m->get_single('admin', 'id_user', $this->session->userdata('koperasi_admin'));
		$this->load->view('user_setting_v', $data);
	}	

    public function login() {
        if ($this->session->userdata('koperasi_admin')) {
            redirect(base_url());
        }
        $this->load->view('user_login_v');
    }

    public function dologin() {
        $this->load->library('form_validation');
        $data['error'] = FALSE;
        //#1 Set Form Validation
        $this->form_validation->set_rules('username', 'Username', 'xss_clean|required|trim');
        $this->form_validation->set_rules('password', 'Password', 'xss_clean|required|trim');				
        if ($this->form_validation->run($this) == FALSE) {
            //#2 Display Error Message
            $data['error'] = validation_errors();
        } else {
            $email = $this->input->post("username");
            $pass = md5($this->input->post('password'));

            $user = $this->auth_m->cek_login($email, $pass);
            if(!empty ($user)){
				if($user->status==1){					
					$this->session->set_userdata('antrian_admin',$user->id);
					redirect(base_url('dashboard'));
				} else {
					$data['error'] = "Akun anda nonaktif.";
				}
            }
            else{
                $data['error'] = "Check your Username & Password";
            }
        }
        $this->load->view('user_login_v', $data);
    }

    public function logout(){		
    	 $this->session->set_userdata('antrian_admin');
		 redirect(base_url('user/login'));
    }

	public function add(){
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();
		$data['success']='';
		$data['error']='';
		$data['edit'] = '';
		$data['title']='Add Member';
		$data['nik'] = htmlspecialchars($this->input->post("nik"));
		$data['nama'] = htmlspecialchars($this->input->post("nama"));
		$data['tempat'] = htmlspecialchars($this->input->post("tempat"));
		$data['tanggal'] = htmlspecialchars($this->input->post("tanggal"));
		$data['jk'] = htmlspecialchars($this->input->post("jk"));
		$data['gd'] = htmlspecialchars($this->input->post("gd"));
		$data['alamat'] = htmlspecialchars($this->input->post("alamat"));
		$data['provinsi'] = htmlspecialchars($this->input->post("provinsi"));
		$data['kota'] = htmlspecialchars($this->input->post("kota"));
		$data['agama'] = htmlspecialchars($this->input->post("agama"));
		$data['sk'] = htmlspecialchars($this->input->post("sp"));
		$data['warga'] = htmlspecialchars($this->input->post("warga"));
		$data['notelp'] = htmlspecialchars($this->input->post("notelp"));
		$data['pekerjaan'] = htmlspecialchars($this->input->post("pekerjaan"));
		$data['email'] = htmlspecialchars($this->input->post("email"));
        if($this->input->post("daftar")){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('nik', 'NIK', 'required|is_unique[users.nik]');
			$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
			if(!empty($data['email']))
				$this->form_validation->set_rules('email', 'Alamat Email', 'required|valid_email|is_unique[users.email]');
			$this->form_validation->set_message('required', '%s tidak boleh kosong');
			$this->form_validation->set_message('valid_email', 'Alamat email tidak valid');
			$this->form_validation->set_message('is_unique', '%s sudah terdaftar');
			if ($this->form_validation->run($this) == FALSE) {
				$data['error'] = validation_errors();
			} else {
				$ups = array(
					'nik' => $data['nik'],
					'email' => $data['email'],
					'password' => md5($this->input->post('password')),
					'nama' => $data['nama'],
					'tempat_lahir' => $data['tempat'],
					'tanggal_lahir' => date("Y-m-d",strtotime($data['tanggal'])),
					'jenis_kelamin' => $data['jk'],
					'golongan_darah' => $data['gd'],
					'alamat' => $data['alamat'],
					'provinsi' => $data['provinsi'],
					'kabupaten' => $data['kota'],
					'agama' => $data['agama'],
					'status_perkawinan' => $data['sk'],
					'pekerjaan' => $data['pekerjaan'],
					'kewarganegaraan' => $data['warga'],
					'tanggal_daftar' => date('Y-m-d'),
					'verified' => 1,
					'notelp' => $data['notelp']
				);
				$insert = $this->user_m->insert('users',$ups);
				if($insert){
					$dp = $this->rekening_m->get_jenis_pokok();
					$pokok = array(
						'iduser' => $insert,
						'jenis' => $dp->jenis,
						'tahun' => $this->rekening_m->get_tahun()->tahun,
						'jumlah' => $dp->nominal,
						'tanggal_billing' => date('Y-m-d')
					);
					$inser = $this->rekening_m->insert('rekening',$pokok);
					redirect(base_url().'user/member/?alert=success');
				}
			}
		}
		if(empty($data['provinsi'])) $data['provinsi']=11;
		$data['prov'] = $this->user_m->get_all_prov();
		$data['kot'] = $this->user_m->get_all_reg($data['provinsi']);
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
		$this->load->view('user_add_v', $data);
	}

	public function edit($id=''){
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();
		$data['success']='';
		$data['error']='';
		$data['title']='Edit Member';
		if($this->input->post("daftar")){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('nik', 'NIK', 'required');
			$email = $this->input->post("email");
			if(!empty($email))
				$this->form_validation->set_rules('email', 'Alamat Email', 'required|valid_email');
				$this->form_validation->set_rules('noanggota', 'No Anggota', 'required|numeric');
			$this->form_validation->set_message('required', '%s tidak boleh kosong');
			$this->form_validation->set_message('valid_email', 'Alamat email tidak valid');
			$this->form_validation->set_message('numeric', '%s harus berupa nomor');
			if ($this->form_validation->run($this) == FALSE) {
				$data['error'] = validation_errors();
			} else {
				$data['nik'] = htmlspecialchars($this->input->post("nik"));
				$data['noanggota'] = htmlspecialchars($this->input->post("noanggota"));
				$data['nama'] = htmlspecialchars($this->input->post("nama"));
				$data['tempat'] = htmlspecialchars($this->input->post("tempat"));
				$data['tanggal'] = htmlspecialchars($this->input->post("tanggal"));
				$data['jk'] = htmlspecialchars($this->input->post("jk"));
				$data['gd'] = htmlspecialchars($this->input->post("gd"));
				$data['alamat'] = htmlspecialchars($this->input->post("alamat"));
				$data['provinsi'] = htmlspecialchars($this->input->post("provinsi"));
				$data['kota'] = htmlspecialchars($this->input->post("kota"));
				$data['agama'] = htmlspecialchars($this->input->post("agama"));
				$data['sk'] = htmlspecialchars($this->input->post("sp"));
				$data['warga'] = htmlspecialchars($this->input->post("warga"));
				$data['notelp'] = htmlspecialchars($this->input->post("notelp"));
				$data['pekerjaan'] = htmlspecialchars($this->input->post("pekerjaan"));
				$data['email'] = htmlspecialchars($this->input->post("email"));
				$ups = array(
					'nik' => $data['nik'],
					'email' => $data['email'],
					'nama' => $data['nama'],
					'tempat_lahir' => $data['tempat'],
					'tanggal_lahir' => date("Y-m-d",strtotime($data['tanggal'])),
					'jenis_kelamin' => $data['jk'],
					'golongan_darah' => $data['gd'],
					'alamat' => $data['alamat'],
					'provinsi' => $data['provinsi'],
					'kabupaten' => $data['kota'],
					'agama' => $data['agama'],
					'status_perkawinan' => $data['sk'],
					'pekerjaan' => $data['pekerjaan'],
					'kewarganegaraan' => $data['warga'],
					'tanggal_daftar' => date('Y-m-d'),
					'notelp' => $data['notelp'],
					'noanggota' => $data['noanggota']
				);
				$insert = $this->user_m->update('users','id',$id,$ups);
				if($insert){
					redirect(base_url().'user/member/?alert=success');
				} else {
					$data['error'] = 'gagal';
				}
			}
		}
		$data['data']=$this->user_m->get_single('users', 'id', $id);
		$data['prov'] = $this->user_m->get_all_prov();
		if (empty($data['data']->provinsi)) {
			$data['data']->provinsi = 11;
		}
		$data['kot'] = $this->user_m->get_all_reg($data['data']->provinsi);
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
		$this->load->view('user_edit_v', $data);
	}

	public function del($id=''){
		$cek = $this->rekening_m->cek_hapus($id);
		if($cek){
			$del = $this->user_m->delete('users', 'id', $id);
			if ($del){
				$del = $this->user_m->delete('rekening', 'iduser', $id);
				redirect(base_url().'user/member/?alert=success');
			}
		} else {
			redirect(base_url().'user/member/?alert=failed');
		}
	}

	public function active($id=''){

		$del = $this->user_m->update('users', 'id', $id, array('verified'=>1));
    	if ($del){
				$this->rekening_m->update('rekening','iduser',$id,['aktif'=>0]);
            redirect(base_url().'user/member/?alert=success');
		}
		redirect(base_url().'user/member/?alert=failed');
	}

	public function banned($id=''){

		$del = $this->user_m->update('users', 'id', $id, array('verified'=>2));
    	if ($del){
				$this->rekening_m->update('rekening','iduser',$id,['aktif'=>1]);
            redirect(base_url().'user/member/?alert=success');
		}
		redirect(base_url().'user/member/?alert=failed');
	}

	public function member(){
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
		if(isset($_GET['alert'])){$data['alert']=$_GET['alert'];}
		else{$data['alert']='';}

                 if(isset($_GET['hal'])){$hal=$_GET['hal'];}
                else {$hal='';}
				if(isset($_GET['s'])) $s = $_GET['s']; else $s='';
				$dataPerhalaman=10;
				($hal=='')?$nohalaman = 1:$nohalaman = $hal;
                $offset = ($nohalaman - 1) * $dataPerhalaman;
                $off = abs( (int) $offset);
                $data['offset']=$offset;
				$jmldata=$this->user_m->count_all_member_search($s);
                $data['paginator']=$this->user_m->page($jmldata, $dataPerhalaman, $hal);
                $data['datas']=$this->user_m->get_member_by_search($s,$dataPerhalaman,$off);
                $data['s']=$s;
		$data['title'] = 'Member';
		$data['jmldata'] = $jmldata;
		$this->load->view('user_member_v', $data);
	}

	public function lap_member(){
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
		if(isset($_GET['alert'])){$data['alert']=$_GET['alert'];}
		else{$data['alert']='';}
		if(isset($_GET['hal'])){$hal=$_GET['hal'];}
		else {$hal='';}
		if(isset($_GET['s'])) $s = $_GET['s']; else $s='';
		if(isset($_GET['idp'])) $data['idp'] = $_GET['idp']; else $data['idp']='';
		if(isset($_GET['idk'])) $data['idk'] = $_GET['idk']; else $data['idk']='';
		$dataPerhalaman=15;
		($hal=='')?$nohalaman = 1:$nohalaman = $hal;
		$offset = ($nohalaman - 1) * $dataPerhalaman;
		$off = abs( (int) $offset);
        $data['offset']=$offset;
		$jmldata=$this->user_m->count_all_member_search_lap($s,$data['idp'],$data['idk']);
        $data['paginator']=$this->user_m->page($jmldata, $dataPerhalaman, $hal);
        $data['datas']=$this->user_m->get_member_by_search_lap($s,$data['idp'],$data['idk'],$dataPerhalaman,$off);
        $data['s']=$s;
		$data['prov'] = $this->user_m->get_all_prov();
		if(!empty($data['idp']))$data['kot'] = $this->user_m->get_all_reg($data['idp']); else $data['kot'] = '';
		$data['title'] = 'Laporan Anggota';
		$data['jmlh'] = $jmldata;
		$this->load->view('user_lap_member_v', $data);
	}

	public function lap_member_excel(){
		$s = $this->input->post('s');
		$idk = $this->input->post('idk');
		$idp = $this->input->post('idp');
        $data['datas']=$this->user_m->get_member_by_search_lap_all($s,$idp,$idk);
        $this->load->view('excel-user-lap', $data);
	}
	public function lap_member_pdf(){
		$s = $this->input->post('s');
		$idk = $this->input->post('idk');
		$idp = $this->input->post('idp');
        $data['datas']=$this->user_m->get_member_by_search_lap_all($s,$idp,$idk);
		$data['s']='';
		$data['info'] = $this->user_m->get_single('info', 'id', 1);
		$data['kota'] = $this->user_m->get_single('regencies', 'id', $idk)->nameregen;
		$data['prov'] = $this->user_m->get_single('provinces', 'id', $idp)->nameprov;
        $this->load->view('pdf/report5', $data);
	}

	public function add_member() {
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
        $data = array();
		$data['edit'] = 'member';
        $data['add'] = 'member';
        $data['success'] = '';
        $data['error'] = '';
        $data['title'] = 'Add Member';
        if ($this->input->post('simpan')) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('username', 'Username', 'required|trim|xss_clean|is_unique[user.username]');
			$this->form_validation->set_rules('nama_user', 'Name User', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required|matches[passconf]|min_length[6]');
			$this->form_validation->set_rules('passconf', 'Password Confirmation', 'required');
            if ($this->form_validation->run() == FALSE) {
                $data['error'] = validation_errors();
            } else {

                $input = array(
                    'username' => $this->input->post('username'),
					'password' => md5($this->input->post('password')),
					'nama' => $this->input->post('nama_user'),
					'email' => $this->input->post('alamat'),
                    'status' => 1,
					'id_group' => 2 //$this->input->post('id_level')
                );
                $insert1 = $this->user_m->insert('user', $input);
                if ($insert1)
                    $data['success'] = 'success';
                else
                    $data['error'] = 'failed';
            }
        }
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
        $this->load->view('user_add_v', $data);
    }

    public function edit_member($id = '') {
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
        $data = array();
        $data['edit'] = 'member';
        $data['success'] = '';
        $data['error'] = '';
        $data['title'] = 'Edit Sales';

        if ($this->input->post('simpan')) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('nama_user', 'Name User', 'required');;
			$this->form_validation->set_rules('status', 'Status', 'required');
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			}
		    else{
		    // if($this->user_m->cek_username($id, $this->input->post('username'))==0){
			$input=array(
				// 'username' => $this->input->post('username'),
				'nama_user' => $this->input->post('nama_user'),
				'alamat_user' => $this->input->post('alamat'),
				'notelp_user' => $this->input->post('telpon'),
                'status' => $this->input->post('status'),
				'level' => 1
			);
			if($this->input->post('id_status')==0){
				$status = 'deleted';
			} else {
				$status = 'verifed';
			}
            $this->db->trans_begin();
			$insert=$this->user_m->update('user', 'id_user', $id, $input);
            $log = $this->user_m->insert('user_status_log', array(
                'id_user' => $id,
                'id_admin' => $this->session->userdata('antrian_admin')->id_user,
                'status' => $status,
                'date_added' => date('Y-m-d H:i:s')
                ));

                if ($this->db->trans_status() === TRUE) {
                    $this->db->trans_commit();
                    $data['success'] = 'success';
                } else {
                    $data['error'] = 'failed';
                    $this->db->trans_rollback();
                }
            }
        }
        $data['data'] = $this->user_m->get_single('user', 'id_user', $id);
        $this->load->view('user_edit_v', $data);
    }

	/////USERS MEMBER
	public function index(){
		redirect(base_url() . "user/member");
	}


	public function profile($id=''){
                if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		if($id==''){redirect(base_url('dashboard'));}
		$data=array();
		$data['success']='';
		$data['error']='';
		$data['title']='Profile';
		if($this->input->post('simpan')){
			$input=array(
				'username' => $this->input->post('username'),
				'nama_user' => $this->input->post('nama_user'),
				'alamat_user' => $this->input->post('alamat'),
				'notelp_user' => $this->input->post('telpon')
			);
			$update=$this->user_m->update('user', 'id_user', $this->session->userdata('antrian_admin')->id_user, $input);
			// echo $update;exit;
			if($update){$data['success']='success';}else{$data['error']='Failed';}
		}
		$data['data']=$this->user_m->get_single('user', 'id_user', $this->session->userdata('antrian_admin')->id_user);
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
		$this->load->view('user_profil_v', $data);
	}

	////////FORGET PASSWROD
	function forgotpass(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_message('required', '%s tidak boleh kosong');
        $this->form_validation->set_message('valid_email', 'Alamat email tidak valid');
		 if($this->input->post("submit")){
			if ($this->session->userdata('captcha') != $this->input->post('test')) {
				$data['error'] = "Kode captcha anda salah, coba lagi.";
			} else if ($this->form_validation->run() == FALSE){
                $data['error'] = validation_errors();
            }else{
				$users = $this->user_m->get_user_by_email($this->input->post('email'));
				if(empty($users)){
					$data['error'] = "Akun email anda tidak terdaftar";
				} else {
					$kode_random = random_string('alnum', 21);
					$input = array(
						'password' => ''
					);
					$hasil=$this->user_m->update('admin','id_user',$users->id_user,$input);
					$email_dihash = str_replace('@', md5('@'), $this->input->post('email'));
					$data_email = '<strong>Administrator Koperasi Perumahan Nasional Yth,</strong>

						<p>Terimakasih telah setia menjadi anggota <a style="text-decoration:none" href="http://koperumnas.com/">Koperumnas.com</a>. Silahkan mengikuti tautan dibawah ini untuk melakukan reset password</p>                    <br/>
						<br/>
						<div style="text-align: center;">
							<a href="'.base_url().$this->config->slash_item('index_page').'user/reset/'.$users->id_user.'/'.$email_dihash.'" style="font-size:15px; padding:10px; cursor:pointer; background-color: #4d90fe;border: 1px solid #3079ed;color: #fff;text-decoration: none;">Reset Password</a>
						</div>
						<br/>
						<br/>
						<br/>

						';
					$config=$this->_mail_win();
					$this->load->library('email', $config);
					$this->email->set_newline("\r\n");
					$this->email->from($this->config->item('email_from'), 'Koperasi Perumahan Nasional');
					$this->email->to($this->input->post('email'));
					$this->email->subject('Reset password administrator koperumnas.com');
					$this->email->message($data_email);
					$send = $this->email->send();
					if($send) {
						$data['berhasil'] = 'Permintaan reset password berhasil, silakan lakukan aktifasi pada email anda';
					}
				}
			}
        }
		$min_number = 0;
		$max_number = 20;
		$data['rn1'] = mt_rand($min_number, $max_number);
		$data['rn2'] = mt_rand($min_number, $max_number);
		$this->session->set_userdata('captcha',$data['rn1']+$data['rn2']);
        $this->load->view('user_fpass_v', $data);
	}

	public function reset($id_user='', $email='', $token=''){
		$data = array();
		if($id_user=='' OR $email=='') redirect(base_url(), 'refresh');
		$data['aktivasi_berhasil'] = FALSE;
		$data['email']=str_replace(md5('@'), '@', $email);
		if($this->user_m->cek_reset($id_user,$data['email'])){
			$data['ada'] = 'b';
		} else {
			$data['fail'] = 'f';
		}
		if($this->input->post('submit')){
			$data['active'] = 1;
			$this->load->library('form_validation');
			$this->form_validation->set_rules('password', 'Password Baru', 'required|matches[passconf]|min_length[6]');
			$this->form_validation->set_rules('passconf', 'Konfirmasi password', 'required');
			$this->form_validation->set_message('matches', 'Password tidak sama.');
			$this->form_validation->set_message('required', '%s tidak boleh kosong');
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			}else{
		    	$ganti=$this->user_m->update('admin', 'id_user', $id_user, array('password'=>md5($this->input->post('password'))));
		    	if($ganti){
					$data['berhasil'] = "Reset Password anda berhasil. Silahkan klik tautan ini untuk menuju ke <a href='".base_url()."' style='color:#fff;'>halaman masuk</a> ";
				} else{
					$data['error'] = "Ubah password gagal";
				}
		    }
		}
		$this->load->view('user_forgot_v', $data);
	}

    function _mail_win()
    {
        $config = Array(
            'protocol' => $this->config->item('protocol'),
            'smtp_host' => $this->config->item('smtp_host'),
            'smtp_port' => $this->config->item('smtp_port'),
            'smtp_user' => $this->config->item('smtp_user'),
            'smtp_pass' => $this->config->item('smtp_pass'),
            'mailtype' => $this->config->item('mailtype'),
            'charset' => $this->config->item('charset'),
            'smtp_crypto' => $this->config->item('smtp_crypto')
        );
        return $config;
    }

    function _mail_unix()
    {
        $config = array(
            'mailtype' => $this->config->item('mailtype'),
            'charset' => $this->config->item('charset')
        );
        return $config;
    }


}

/* End of file  */
/* Location: ./application/controllers/ */
