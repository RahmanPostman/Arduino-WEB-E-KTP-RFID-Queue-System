<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class auth_m extends My_Model{

	function __construct() {
		parent::__construct();
	}
	function cek_login($admin,$pass){
		$sql = "SELECT * FROM user a join loket b on a.idloket = b.idloket WHERE username='$admin' AND password = '$pass'";
		$res = $this->db->query($sql);
		$r='';
		if ($res->num_rows() > 0) {
            $r = $res->row();
        }else {
        	$r = false;
        }
		return $r;
	}

	function get_admin_by_id($admin){
		$res = $this->db->query("SELECT * FROM user a join loket b on a.idloket = b.idloket WHERE id=$admin");
		$r = $res->row();
		$res->free_result();
		return $r;
	}

	function get_admin_by($admin){
		$res = $this->db->query("SELECT * FROM user WHERE username='$admin'");
		$r = $res->row();
		$res->free_result();
		return $r;
	}

	function get_admin(){
    	if($this->session->admindata('koperasi_admin')){
    		//$data=$this->get_single('admin', 'id_admin', $this->session->admindata('koperasi_admin')->id_admin);
			$sql = $this->db->query('SELECT * FROM user WHERE id_admin="'.$this->session->admindata('koperasi_admin')->id_admin.'"');
			$data = $sql->row();
    	}
    	return $data;
    }

	function check() {
        if (!$this->session->admindata('koperasi_admin')) {
            redirect(base_url(), 'refresh');
        }
    }

	function cek_password($id='', $pass=''){
		$sql="SELECT COUNT(*) AS jumlah FROM user WHERE id='".$id."' AND password='".$pass."' ";
		$q=$this->db->query($sql);
		$data = $q->row();
		$q->free_result();
		return $data->jumlah;
	}

	function get_last_log($id=''){
		$sql="SELECT * FROM log_admin WHERE idadmin='$id' and status = 0 ORDER BY id DESC";
		$q=$this->db->query($sql);
		$data = $q->row();
		$q->free_result();
		return $data;
	}

	function update_log($id=''){
		$last_log = $this->get_last_log($id);
		if(!empty($last_log)){
			$insert = $this->update('log_admin','id',$last_log->id,array('status'=>1,'keluar'=>date('Y-m-d h:i:s')));
		}
	}

	function insert_log($id=''){
		$this->update_log($id);
		$insert = $this->insert('log_admin',array('idadmin'=>$id));
	}

}

/* End of file admin_model.php */
/* Location: ./application/models/admin_Model.php */
