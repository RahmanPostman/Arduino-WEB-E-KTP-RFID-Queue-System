			<br/>
			<div class="col-md-12">
				<div class="alert alert-success"><strong>Terimakasih </strong> Data E-KTP anda ditemukan silahkan langsung pilih Antria sesuai keperluan anda</div>
			</div>
			<div class="panel panel-primary" data-collapsed="0">
				
					<div class="panel-heading">
						<div class="panel-title">
							<h3>Form Pendaftaran Antrian</h3>
						</div>												
					</div>
					
					<div class="panel-body">
						
						<form role="form" class="form-horizontal form-groups-bordered">
			
							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label">NIK</label>								
								<div class="col-sm-8">
									<input type="text" class="form-control" id="nik" placeholder="NIK" name="nik" readonly="true" value="<?= $user->nik?>">
								</div>
							</div>
							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label">Nama</label>								
								<div class="col-sm-8">
									<input type="text" class="form-control" id="nama" placeholder="Nama" name="nama" readonly="true" value="<?= $user->nama?>">
								</div>
							</div>
							<input type="hidden" id="key" placeholder="Nama" name="idk" value="<?= $user->idktp?>" >
							<div class="form-group">
								<?php foreach($group as $d){ ?>
								<div class="col-sm-3">
									<button type="button" onclick="daftar(<?= $d->idgroup?>)" class="btn btn-<?= $d->btn; ?> btn-lg">Antri ke <?= $d->group?></button>
								</div>
								<?php } ?>
							</div>
						</form>
						
					</div>
				
				</div>