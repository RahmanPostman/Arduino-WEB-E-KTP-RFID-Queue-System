<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class petugasloket extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_m');		
		$this->load->model('auth_m');        
		$this->load->model('antrian_m');        
	}

	public function index(){        
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
		if(isset($_GET['alert'])){$data['alert']=$_GET['alert'];}
		else{$data['alert']='';}                
        if(isset($_GET['hal'])){$hal=$_GET['hal'];}
        else {$hal='';}
		if(isset($_GET['s'])) $s = $_GET['s']; else $s='';
		$dataPerhalaman=10;
		($hal=='')?$nohalaman = 1:$nohalaman = $hal;
        $offset = ($nohalaman - 1) * $dataPerhalaman;
        $off = abs( (int) $offset);
        $data['offset']=$offset;
		$jmldata=$this->user_m->count_all_petugas_search($s);
        $data['paginator']=$this->user_m->page($jmldata, $dataPerhalaman, $hal);
        $data['datas']=$this->user_m->get_petugas_by_search($s,$dataPerhalaman,$off);
        $data['s']=$s;                                   
		$data['title'] = 'Petugas Loket';
		$this->load->view('ploket_v', $data);				
	}			
	
	public function add(){
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();		
		$data['success']='';
		$data['error']='';
		$data['title']='Tambah Administrator';		
		if($this->input->post('simpan')){
			$this->load->library('form_validation');			
			$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');			
			$this->form_validation->set_rules('username', 'Username', 'required|is_unique[user.username]');			
			$this->form_validation->set_message('required', '%s tidak boleh kosong');			
			$this->form_validation->set_message('is_unique', '%s sudah terdaftar'); 			
			if ($this->form_validation->run($this) == FALSE) {				
				$data['error'] = validation_errors();
			} else {
				$input=array(				
					'username' => $this->input->post('username'),
					'password' => md5($this->input->post('password')),
					'nama' => $this->input->post('nama'),
					'idloket' => $this->input->post('loket'),
					'tipe' => 2
				);
				$update=$this->user_m->insert('user', $input);			
				if($update){redirect(base_url().'petugasloket/?alert=success');}else{$data['error']='Failed';}
			}			
		}
		$data['loket']=$this->antrian_m->get_loket();
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
		$this->load->view('ploket_add_v', $data);
	}	
	
	public function edit($id){
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();		
		$data['success']='';
		$data['error']='';
		$data['title']='Edit Administrator';
		if($this->input->post('simpan')){
			$this->load->library('form_validation');						
			$this->form_validation->set_rules('loket', 'Loket', 'required');									
			if ($this->form_validation->run($this) == FALSE) {				
				$data['error'] = validation_errors();
			} else {
				$input=array(				
					'nama' => $this->input->post('nama'),				
					'idloket' => $this->input->post('loket')
				);
				$update=$this->user_m->update('user', 'id', $id, $input);			
				if($update){redirect(base_url().'petugasloket/?alert=success');}else{$data['error']='Failed';}
			}			
		}
		$data['data']=$this->user_m->get_user_by_id($id);
		$data['loket']=$this->antrian_m->get_loket();
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
		$this->load->view('ploket_edit_v', $data);
	}
		
	public function del($id=''){
		//$cek = $this->rekening_m->cek_hapus_admin($id);
		//if($cek){
			$del = $this->user_m->delete('user', 'id', $id);
			if ($del){
				redirect(base_url().'petugasloket/?alert=success');			
			}		
		//} else {
			//redirect(base_url().'petugasloket/?alert=failed');			
		//} 
	}
	
	public function active($id=''){
		
		$del = $this->user_m->update('user', 'id', $id, array('status'=>1));
    	if ($del){
            redirect(base_url().'petugasloket/?alert=success');
		}
		redirect(base_url().'petugasloket/?alert=failed');
	}
		
	public function banned($id=''){
		
		$del = $this->user_m->update('user', 'id', $id, array('status'=>2));
    	if ($del){
            redirect(base_url().'petugasloket/?alert=success');			
		}		
		redirect(base_url().'petugasloket/?alert=failed');
	}
	       
    
}

/* End of file  */
/* Location: ./application/controllers/ */
