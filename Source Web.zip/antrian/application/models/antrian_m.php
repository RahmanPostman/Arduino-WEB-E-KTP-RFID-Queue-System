<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class antrian_m extends My_Model{

	function __construct() {
		parent::__construct();
	}	
	
	function get_user($id){		
		$sql = "SELECT * from tamu where nik = '$id'";
		$res = $this->db->query($sql);
		$r=$res->row();
		$res->free_result();
		return $r;
	}
	
	function get_group(){		
		$sql = "SELECT * from groups ";
		$res = $this->db->query($sql);
		$r=$res->result();
		$res->free_result();
		return $r;
	}
	
	function cek_hapus($id){
		$sql = "SELECT * from user where idloket=$id";
		$res = $this->db->query($sql);
		$r=$res->result();
		$res->free_result();
		return $r;
	}
	
	function cek_hapus_g($id){
		$sql = "SELECT * from loket where idgroup=$id";
		$res = $this->db->query($sql);
		$r=$res->result();
		$res->free_result();
		return $r;
	}
	
	function get_loket(){		
		$sql = "SELECT * from loket a join groups b on a.idgroup = b.idgroup";
		$res = $this->db->query($sql);
		$r=$res->result();
		$res->free_result();
		return $r;
	}
	
	
	function getlast($id){
		$sql = "SELECT * from antrian where idgroup = $id order by tanggal desc";
		$res = $this->db->query($sql);
		$r=1;
		if(!empty($res->row()))
			$r=$res->row()->no+1;			
		$res->free_result();
		return $r;
	}
	
	function get_antrian($nama,$idg){		
		$sql = "SELECT * from antrian a join groups b on a.idgroup = b.idgroup join tamu c on a.nik = c.nik
				WHERE status < 2 AND ( c.nama LIKE '%$nama%' or c.nik LIKE '%$nama%')";
		if(!empty($idg))
			$sql.=" AND  idgroup = $id";
		$sql.= " ORDER BY a.status DESC, a.tanggal ASC";	
		$res = $this->db->query($sql);
		$r=$res->result();
		$res->free_result();
		return $r;
	}		
	
	function get_last_antrian(){		
		$sql = "SELECT * from antrian a join groups b on a.idgroup = b.idgroup
				WHERE status < 2 GROUP BY a.idgroup ORDER BY a.id DESC, a.idgroup DESC ";
		$res = $this->db->query($sql);
		$r=$res->result();
		$res->free_result();
		return $r;
	}		
	
	function get_last_antrian_group($id){		
		$sql = "SELECT * from antrian a join groups b on a.idgroup = b.idgroup
				WHERE status = 1 AND a.idgroup=$id ORDER BY a.id DESC";
		$res = $this->db->query($sql);
		$r=$res->row();
		$res->free_result();
		return $r;
	}		
	
	function get_last_antrian_loket($id){		
		$sql = "SELECT a.*,b.*,d.nama,c.loket as loket_now from antrian a join groups b on a.idgroup = b.idgroup join loket c on c.idgroup = b.idgroup
				join tamu d on d.nik = a.nik WHERE status = 1 AND c.idloket = $id AND a.loket = c.loket  GROUP BY a.idgroup ORDER BY a.id ASC ";
		$res = $this->db->query($sql);
		$r=$res->row();
		$res->free_result();
		return $r;
	}	
	
	function get_last_antrian_id($id){		
		$sql = "SELECT a.*,b.*,d.nama,c.loket as loket_now  from antrian a join groups b on a.idgroup = b.idgroup join loket c on c.idgroup = b.idgroup
				join tamu d on d.nik = a.nik WHERE status < 2 AND c.idloket = $id AND a.loket = '0' GROUP BY a.idgroup ORDER BY a.id ASC ";
		$res = $this->db->query($sql);
		$r=$res->row();
		$res->free_result();
		return $r;
	}		
	
	function get_new_antrian($id){
		$sql = "SELECT * from antrian  WHERE status = 1 AND id NOT IN($id) ORDER BY id ASC ";
		$res = $this->db->query($sql);
		$r=$res->result();
		$res->free_result();
		return $r;
	}
	
	function get_lost_antrian($id){
		$sql = "SELECT * from antrian  WHERE status = 2 AND id IN($id) ORDER BY id ASC ";
		$res = $this->db->query($sql);
		$r=$res->result();
		$res->free_result();
		return $r;
	}
	
	function get_antrian_id($id){		
		$sql = "SELECT * from antrian a join groups b on a.idgroup = b.idgroup join tamu c on a.nik = c.nik 
				WHERE id=$id";
		$res = $this->db->query($sql);
		$r=$res->row();
		$res->free_result();
		return $r;
	}	
	
	function get_new_antrian_by_id($id){		
		$sql = "SELECT * from antrian a join groups b on a.idgroup = b.idgroup join tamu c on a.nik = c.nik 
				WHERE id>$id";
		$res = $this->db->query($sql);
		$r=$res->result();
		$res->free_result();
		return $r;
	}	
}

/* End of file admin_model.php */
/* Location: ./application/models/admin_Model.php */
