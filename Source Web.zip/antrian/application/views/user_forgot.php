<!DOCTYPE html>
	<head>
		<meta charset="utf-8">
		<title>Administrator Koperumnas Login</title>
		<meta name="description" content="slick Login">
		<meta name="author" content="Webdesigntuts+">
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>asset/admin/login/style.css" />
		<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
		<script src="http://www.modernizr.com/downloads/modernizr-latest.js"></script>
		<script type="text/javascript" src="<?= base_url() ?>asset/admin/login/placeholder.js"></script>
	</head>
	<body>
		<form id="slick-login" style="text-align:center" action="<?= base_url()?>user/dologin" method="POST">			
			<h4>Form Lupa Password Admin</h4><br/>
			<?php
				if(!empty ($error)){
			?>
			<span style="color:white;"><?= $error ?></span>
			<?php
				}
			?>
			<label for="email">username</label><input type="text" name="email" class="placeholder" placeholder="username"><br/>			
			<br/>
			<input type="submit" name="submit" value="Reset Password">			
		</form>
	</body>
</html>