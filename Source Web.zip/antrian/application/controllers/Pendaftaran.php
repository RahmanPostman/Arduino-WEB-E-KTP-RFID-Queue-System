<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pendaftaran extends CI_Controller {

    function __construct(){
        parent::__construct();        
		$this->load->model('antrian_m');		
    }
   	
	public function index(){
		$id = $this->input->post('group');
		$s = $this->input->post('s');		
		$data['antrian_m'] =$this->antrian_m;
		$data['last'] =$this->antrian_m->get_group();
		$this->load->view('daftar_v', $data);
	}
	
	public function tambah(){
		if($this->input->post('tambah')){
			$data['active'] = 2;
			$this->load->library('form_validation');
			$this->form_validation->set_rules('nama', 'Nama', 'required');
			$this->form_validation->set_rules('nik', 'NIK', 'required');
			$this->form_validation->set_message('required', '%s tidak boleh kosong');
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			}
		    else{
		    	$user=$this->antrian_m->get_user($this->input->post('nik'));
		    	if(empty($user)){
					$input=array(
						'nik' => $this->input->post('nik'),
						'nama' => $this->input->post('nama'),
						'idktp' => $this->input->post('idktp')
					);
		    		$insert=$this->antrian_m->insert('tamu',$input);		    		
		    	}
				$input=array(
					'nik' => $this->input->post('nik'),
					'idgroup' => $this->input->post('group'),
					'no' => $this->antrian_m->getlast($this->input->post('group'))
				);
		    	$insert=$this->antrian_m->insert('antrian',$input);		    		
		    }
		}
		$data['group'] =$this->antrian_m->get_group();
		$this->load->view('tambah_v', $data);
	}		

	public function ajax(){					
		$key = $this->antrian_m->get_single('tampung', 'id', 1)->s;		
		$data['key'] = trim($key);
		$data['group'] =$this->antrian_m->get_group();
		if(!empty($key)){
			$update = $this->antrian_m->update('tampung', 'id', 1,array('s'=>''));
			$data['user'] = $this->antrian_m->get_single('tamu', 'idktp', trim($key));
			if(empty($data['user'])){
				$this->load->view('form_new_v', $data);
			} else {
				$this->load->view('form_v', $data);
			}			
		}
	}
}

		
		