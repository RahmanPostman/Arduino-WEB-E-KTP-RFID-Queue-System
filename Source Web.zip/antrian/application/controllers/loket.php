<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Loket extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('antrian_m');        
		$this->load->model('auth_m');        
		$this->load->model('user_m');        		
	}

	public function index()
	{
		$data=array();
		if(isset($_GET['alert'])){$data['alert']=$_GET['alert'];}
		else{$data['alert']='';}		
		$data['title']='Loket';
		$data['user'] = $this->auth_m->get_admin_by_id($this->session->userdata('antrian_admin'));		
		$data['data']=$this->antrian_m->get_loket();		
		$this->load->view('jenis_v', $data);
	}

	public function add()
	{
		$data=array();
		$data['user'] = $this->auth_m->get_admin_by_id($this->session->userdata('antrian_admin'));		
		$data['alert']='';
		$data['title']='Tambah Loket';
		$data['error']='';
		if($this->input->post('simpan')){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('loket', 'Loket', 'required|trim|xss_clean|is_unique[loket.loket]');			
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			} else{
				$input=array(
					'loket' => $this->input->post('loket'),					
					'idgroup' => $this->input->post('group')
				);
				$insert=$this->antrian_m->insert('loket', $input);				
				if($insert)	redirect(base_url().'loket/?alert=success') ; 			
				else redirect(base_url().'loket/?alert=failed') ; 			
			}			
		}
		$data['jenis']=$this->antrian_m->get_all_data('loket', 'idloket', 'asc');
		$data['group']=$this->antrian_m->get_group();
		$this->load->view('jenis_add_v', $data);
	}

	public function edit($id='')
	{
		$data=array();
		$data['user'] = $this->auth_m->get_admin_by_id($this->session->userdata('antrian_admin'));		
		$data['alert']='';
		$data['title']='Edit Loket';
		$data['error']='';
		if($this->input->post('simpan')){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('loket', 'Loket', 'required');
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			} else{ 
				$input=array(
					'loket' => $this->input->post('loket'),					
					'idgroup' => $this->input->post('group')					
				);

				$insert=$this->antrian_m->update('loket', 'idloket', $id, $input);				
				if($insert)	redirect(base_url().'loket/?alert=success') ; 			
				else redirect(base_url().'loket/?alert=failed') ; 			
			}			
		}		
		$data['data']=$this->antrian_m->get_single('loket', 'idloket', $id);
		$data['group']=$this->antrian_m->get_group();
		$this->load->view('jenis_edit_v', $data);
	}

	public function delete($id=''){	
		$data = $this->antrian_m->get_single('loket', 'idloket', $id);
		if(!$this->antrian_m->cek_hapus($data->idloket)){
			$del=$this->antrian_m->delete('loket', 'idloket', $id);
			if($del){
				redirect(base_url().'loket/?alert=success') ; 			
			} 
		}
		redirect(base_url().'loket/?alert=failed') ; 			
	}	
}

/* End of file  */
/* Location: ./application/controllers/ */