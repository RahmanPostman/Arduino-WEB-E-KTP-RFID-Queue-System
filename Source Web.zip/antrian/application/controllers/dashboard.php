<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct() {

        parent::__construct();        
		$this->load->model('user_m');
		$this->load->model('auth_m');
		if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
    }

	public function index()
	{        
		$data=array();
		$data['title']='Dashboard';
        $data['user'] = $this->auth_m->get_admin_by_id($this->session->userdata('antrian_admin'));
		$this->load->view('index', $data);
	}	
}

/* End of file dashboard.php */
/* Location: ./application/controllers/dashboard.php */