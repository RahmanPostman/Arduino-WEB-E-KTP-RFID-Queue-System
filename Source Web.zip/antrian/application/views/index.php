<?php include 'header.php'; ?>

      <div id="page-wrapper">
		
        <div class="row">
          <div class="col-lg-12">
            <h1>Dashboard</h1>
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
            </ol>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Welcome to Antrian Online | Dashboards Area			 
            </div>
          </div>
        </div>
      </div><!-- /#page-wrapper -->

<?php include 'footer.php'; ?>
