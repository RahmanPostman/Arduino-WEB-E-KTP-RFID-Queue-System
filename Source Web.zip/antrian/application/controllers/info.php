<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class info extends CI_Controller {

	public function __construct() {

        parent::__construct();        
		$this->load->model('user_m');
		$this->load->model('auth_m');
		if(!$this->session->userdata('koperasi_admin')) redirect(base_url() . "user/login");
    }

	public function index()	
	{
		$data=array();
		$data['user'] = $this->auth_m->get_admin_by_id($this->session->userdata('koperasi_admin'));		
		$data['alert']='';
		$data['title']='Informasi';
		$data['error']='';
		if($this->input->post('simpan')){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('info', 'Info', 'required');
			if ($this->form_validation->run() == FALSE){
				$data['error'] = validation_errors();
			} else{ 
				$input=array(
					'nama' => $this->input->post('nama'),
					'alamat' => $this->input->post('alamat'),
					'notelp' => $this->input->post('notelp'),
					'email' => $this->input->post('email'),
					'info' => $this->input->post('info')
				);
				$insert=$this->user_m->update('info', 'id',1, $input);				
				if($insert) $data['alert']='success';
				else $data['alert'] = 'failed';
			}			
		}		
		$data['data']=$this->user_m->get_single('info', 'id', 1);
		$this->load->view('info_edit_v', $data);
	}
}

/* End of file dashboard.php */
/* Location: ./application/controllers/dashboard.php */