
<?php include 'header.php'; ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
           <h1>Administrator</h1>
			 <ol class="breadcrumb">
              <li><a href="<?=base_url();?>dashboard">Dashboard</a></li>            
              <li><a href="<?=base_url();?>administrator">Administrator</a></li>            
              <li class="active">Tambah</li>
            </ol>
            <?php if($success=='success'){ ?>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Success
            </div>
            <?php } ?>

            <?php if($error!=''){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?=$error;?>
            </div>
            <?php } ?>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-12">
			<form class="form-horizontal"  role="form" method="post" action="<?= base_url()?>administrator/edit/<?= $data->id_user?>">				
				<div class="form-group">
					<label class="col-lg-2 control-label">Nama :</label>
					<div class="col-lg-4">
						<input name="nama" type="text" value="<?= $data->nama?>"  class="form-control radius-3 margin-b-10" id="email" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-lg-2 control-label">Email :</label>
					<div class="col-lg-4">
						<input name="email" type="mail" value="<?= $data->email?>" class="form-control radius-3 margin-b-10" id="email" required>
					</div>
				</div>		
				<div class="clearfix"></div>
                  <br><br>
                <div style="text-align:center;">
                    <button class="btn btn-primary save-product" type="submit" name="simpan" value=1><i class="fa fa-pencil"></i> Ubah</button>
                </div>  				
			</form>
		  </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->	  
<?php include 'footer.php'; ?>