<?php include 'header.php'; ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Petugas Loket Antrian Online</h1>
            <ol class="breadcrumb">
              <li><a href="<?=base_url();?>dashboard">Dashboard</a></li>
              <li class="active">Petugas Loket</li>
            </ol>
            <?php if($alert=='success'){ ?>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Success
            </div>
            <?php } ?>

            <?php if($alert=='failed'){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Failed
            </div>
            <?php } ?>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-12">
            <div class="search">
              <form method="GET" action="" class="form-inline" role="form">                
                <div class="form-group">
                  <input value="<?=$s?>" name="s" type="text" class="form-control" id="" placeholder="Username">
                </div>                
                <button type="submit" class="btn btn-primary">Cari</button>&nbsp;&nbsp;&nbsp;
				<a href="<?=base_url();?>petugasloket/add"><button type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Petugas Loket</button></a>
              </form>
            </div>
            <h3>Data Administrator</h3>            
            <div class="table-responsive">
              <table class="table table-hover table-striped tablesorter">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Nama</th>
                    <th>Username</th>                      
                    <th>Loket</th>                      
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i=0;foreach ($datas as $data) { $i++;?>
                  <tr class="">
                    <td><?=$i;?></td>
                    <td><?= "[".$data->id."] ".$data->nama;?></td>					
                    <td><?=$data->username;?></td>                                    
					<td><?=$data->loket;?></td>                                    
                    <td><?php 
						if($data->status == 1)	 echo 'aktif';
						else if($data->status == 2)	 echo 'banned';
					?></td>				
                    <td>
						<?php if($data->status == '1'){?>
							<a href="<?=base_url().'petugasloket/banned/'.$data->id?>" class="btn btn-warning btn-xs"><i class="fa fa-ban"></i> Banned</a>
						<?php } else if($data->status == '2'){ ?>
							<a href="<?=base_url().'petugasloket/active/'.$data->id?>" class="btn btn-info btn-xs"><i class="fa fa-check"></i> Active</a>
						<?php } ?>
						<a href="<?=base_url();?>petugasloket/edit/<?=$data->id;?>" type="button" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i> Edit</a>
						<a href="<?=base_url();?>petugasloket/del/<?=$data->id;?>" type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Hapus</a> 						
                    </td>                    
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <?=$paginator?>
          </div>
        </div><!-- /.row -->        
        
      </div><!-- /#page-wrapper -->
<?php include 'footer.php'; ?>