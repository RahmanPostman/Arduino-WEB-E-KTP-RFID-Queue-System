n<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class administrator extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_m');		
		$this->load->model('auth_m');
        
	}

	public function index(){        
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();
		$data['user'] = $this->user_m->get_user_by_id($this->session->userdata('antrian_admin'));
		if(isset($_GET['alert'])){$data['alert']=$_GET['alert'];}
		else{$data['alert']='';}                
        if(isset($_GET['hal'])){$hal=$_GET['hal'];}
        else {$hal='';}
		if(isset($_GET['s'])) $s = $_GET['s']; else $s='';
		$dataPerhalaman=10;
		($hal=='')?$nohalaman = 1:$nohalaman = $hal;
        $offset = ($nohalaman - 1) * $dataPerhalaman;
        $off = abs( (int) $offset);
        $data['offset']=$offset;
		$jmldata=$this->user_m->count_all_admin_search($s);
        $data['paginator']=$this->user_m->page($jmldata, $dataPerhalaman, $hal);
        $data['datas']=$this->user_m->get_admin_by_search($s,$dataPerhalaman,$off);
        $data['s']=$s;                                   
		$data['title'] = 'Administrator';
		$this->load->view('admin_v', $data);
				
	}			
	
	public function add(){
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();		
		$data['success']='';
		$data['error']='';
		$data['title']='Tambah Administrator';		
		if($this->input->post('simpan')){
			$this->load->library('form_validation');			
			$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
			$this->form_validation->set_rules('email', 'Alamat Email', 'required|valid_email|is_unique[admin.email]');			
			$this->form_validation->set_rules('username', 'Username', 'required|is_unique[admin.username]');			
			$this->form_validation->set_message('required', '%s tidak boleh kosong');
			$this->form_validation->set_message('valid_email', 'Alamat email tidak valid');
			$this->form_validation->set_message('is_unique', '%s sudah terdaftar'); 			
			if ($this->form_validation->run($this) == FALSE) {				
				$data['error'] = validation_errors();
			} else {
				$input=array(				
					'username' => $this->input->post('username'),
					'password' => md5($this->input->post('password')),
					'nama' => $this->input->post('nama'),				
					'email' => $this->input->post('email'),
					'level' => 2
				);
				$update=$this->user_m->insert('admin', $input);			
				if($update){redirect(base_url().'administrator/?alert=success');}else{$data['error']='Failed';}
			}			
		}
		$data['data']=$this->user_m->get_single('admin', 'id_user', $this->session->userdata('antrian_admin'));
		$data['user'] = $this->user_m->get_single('admin', 'id_user', $this->session->userdata('antrian_admin'));
		$this->load->view('admin_add_v', $data);
	}	
	
	public function edit($id){
        if(!$this->session->userdata('antrian_admin')) redirect(base_url() . "user/login");
		$data=array();		
		$data['success']='';
		$data['error']='';
		$data['title']='Edit Administrator';
		if($this->input->post('simpan')){
			$this->load->library('form_validation');						
			$this->form_validation->set_rules('email', 'Alamat Email', 'required|valid_email');									
			if ($this->form_validation->run($this) == FALSE) {				
				$data['error'] = validation_errors();
			} else {
				$input=array(				
					'nama' => $this->input->post('nama'),				
					'email' => $this->input->post('email')
				);
				$update=$this->user_m->update('admin', 'id_user', $id, $input);			
				if($update){redirect(base_url().'administrator/?alert=success');}else{$data['error']='Failed';}
			}			
		}
		$data['data']=$this->user_m->get_single('admin', 'id_user', $id);
		$data['user'] = $this->user_m->get_single('admin', 'id_user', $this->session->userdata('antrian_admin'));
		$this->load->view('admin_edit_v', $data);
	}
		
	public function del($id=''){
		//$cek = $this->rekening_m->cek_hapus_admin($id);
		//if($cek){
			$del = $this->user_m->delete('admin', 'id_user', $id);
			if ($del){
				redirect(base_url().'administrator/?alert=success');			
			}		
		//} else {
			//redirect(base_url().'administrator/?alert=failed');			
		//} 
	}
	
	public function active($id=''){
		
		$del = $this->user_m->update('admin', 'id_user', $id, array('status'=>1));
    	if ($del){
            redirect(base_url().'administrator/?alert=success');
		}
		redirect(base_url().'administrator/?alert=failed');
	}
		
	public function banned($id=''){
		
		$del = $this->user_m->update('admin', 'id_user', $id, array('status'=>2));
    	if ($del){
            redirect(base_url().'administrator/?alert=success');			
		}		
		redirect(base_url().'administrator/?alert=failed');
	}
	       
    
}

/* End of file  */
/* Location: ./application/controllers/ */
