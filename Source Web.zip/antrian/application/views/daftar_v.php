<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="description" content="Neon Admin Panel" />
	<meta name="author" content="" />

	<link rel="icon" href="<?=base_url();?><?=base_url();?>assets/images/favicon.ico">

	<title>Antrian Online</title>

	<link rel="stylesheet" href="<?=base_url();?>assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css">
	<link rel="stylesheet" href="<?=base_url();?>assets/css/font-icons/entypo/css/entypo.css">
	<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic">
	<link rel="stylesheet" href="<?=base_url();?>assets/css/bootstrap.css">
	<link rel="stylesheet" href="<?=base_url();?>assets/css/neon-core.css">
	<link rel="stylesheet" href="<?=base_url();?>assets/css/neon-theme.css">
	<link rel="stylesheet" href="<?=base_url();?>assets/css/neon-forms.css">
	<link rel="stylesheet" href="<?=base_url();?>assets/css/custom.css">

	<script src="<?=base_url();?>assets/js/jquery-1.11.3.min.js"></script>

	<!--[if lt IE 9]><script src="<?=base_url();?>assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
	
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->


</head>
<body class="page-body  page-fade boxed-layout" data-url="http://neon.dev">

<div class="page-container" style="margin-top: 100px; margin-bottom: 40px; height: auto;"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
	
	
	<div class="main-content">
				
		<div class="row">
		
			<!-- Profile Info and Notifications -->
			<div class="col-md-12 col-sm-12 clearfix">
		
				<h2 style="text-align:center;">Pendaftaran Antrian</h2>
				
			</div>
		
		
			<!-- Raw Links -->			
		</div>
		
		<hr />
							
		
		<div class="row">
			<div class="col-md-6 col-sm-12">															
				<div class="panel panel-info" data-collapsed="0">
					
					<!-- panel head -->
					<div class="panel-heading">
						<div class="panel-title">
							<h3>Informasi Cara Mengantri</h3>
						</div>												
					</div>
					
					<!-- panel body -->
					<div class="panel-body">
						
						<p>Article evident arrived express highest men did boy. Mistress sensible entirely am so. Quick can manor smart money hopes worth too. Comfort produce husband boy her had hearing. Law others theirs passed but wishes. You day real less till dear read. Considered use dispatched melancholy sympathize discretion led. Oh feel if up to till like.</p>
						
					</div>
					
				</div>
				<div class="col-md-12 col-sm-12">				
					<h2 style="text-align:lwft">Antrian Sekarang</h2>
				
					<br />
					<?php foreach($last as $d){ ?>
					<div class="col-sm-6 col-xs-12">
				
						<div class="tile-stats tile-<?= $d->warna?>">
							<div class="icon"><i class="entypo-users"></i></i></div>
							<div class="num" id="group-<?= $d->idgroup?>"></div>			
							<h3><?= $d->group?></h3>						
						</div>
				
					</div>			
					<?php } ?>
				</div>
			</div>
			
			
			<div class="col-md-6 col-sm-12">									
				<blockquote class="blockquote-green" id="gr" style="padding-bottom:50px; padding-top:50px;">
					<strong><h3><center>TEMPELKAN E-KTP ANDA PADA ALAT YANG TERSEDIA</center></h3></strong>
				</blockquote>				
				<blockquote class="blockquote-gold" id="gl" style="padding-bottom:50px; padding-top:50px;">
					<strong><h2><center>No. Antrian Anda Adalah <br/><b id="nobaru">90</b></center></h2></strong>
				</blockquote>				
				<div id="frm"></div>
			</div>			
		</div>	
		
							
		
		
				
		<footer class="main">
			
			&copy; 2017 <strong>3 Tekkom B</strong> 
		
		</footer>
	</div>
		
	
</div>

\
	<!-- Imported styles on this page -->
	<link rel="stylesheet" href="<?=base_url();?>assets/js/zurb-responsive-tables/responsive-tables.css">

	<!-- Imported styles on this page -->
	

	<!-- Bottom scripts (common) -->	
	<script src="<?=base_url();?>assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
	<script src="<?=base_url();?>assets/js/bootstrap.js"></script>
	<script src="<?=base_url();?>assets/js/joinable.js"></script>
	<script src="<?=base_url();?>assets/js/resizeable.js"></script>	

	
	<!-- Imported scripts on this page -->
	<script src="<?=base_url();?>assets/js/zurb-responsive-tables/responsive-tables.js"></script>
	
	<!-- JavaScripts initializations and stuff -->
	<script src="<?=base_url();?>assets/js/neon-custom.js"></script>


	<!-- Demo Settings -->
	<script src="<?=base_url();?>assets/js/neon-demo.js"></script>	
	<script>		
		function ajax_antrian(id){
			$.ajax({
				type	: 'post',
				url		: '<?=base_url();?>ajax/last',
				data	: {id:id},
				success	: function(result){
					$('#group-'+id).html(result);
					setTimeout(function(){
						ajax_antrian(id);
					}, 3000);
				}
			});		
		}				
		function ajax_cek_ktp(){
			$.ajax({
				type	: 'post',
				url		: '<?=base_url();?>pendaftaran/ajax',				
				success	: function(result){
					if(result.length > 0){
						$("#gr").fadeOut(800);
						$("#frm").hide();						
						$("#frm").html(result).hide().fadeIn(900);											
					} else {
						setTimeout(function(){
							ajax_cek_ktp();
						}, 1000);
					}
				}
			});		
		}		
		function daftar(id){
			var nik = $('input[name="nik"]').val();
			var nama = $('input[name="nama"]').val();
			var idk = $('input[name="idk"]').val();			
			if(nama==''){
				alert('Isikan Nama  Anda');
				return
			} else if(nik==''){
				alert('Isikan NIK dari E-KTP Anda');
				return
			}
			
			$.ajax({
				type	: 'post',
				url		: '<?=base_url();?>antrian/tambah',	
				data	: {nama:nama,nik:nik,idk:idk,group:id},				
				success	: function(result){
					if(result.length > 0){						;
						$("#nobaru").html(result);
						$("#frm").fadeOut(500);						
						$("#gl").fadeIn(900);
						setTimeout(function(){
							$("#frm").html();
							$("#gl").fadeOut(800);
							$("#gr").fadeIn(900);		
							ajax_cek_ktp();
						}, 11000);
					}					
				}
			});		
		}				
		<?php foreach($last as $d){ ?>
			ajax_antrian(<?= $d->idgroup?>);
		<?php } ?>
		ajax_cek_ktp();
		$("#gl").hide();
	</script>
</body>
</html>