						<tr id="baris<?= $d->id?>" style="font-size:12px; border-bottom:solid #000 2px; color:#fff;background:<?= (!$d->status)?$d->rgb:'#f56954';?>;" >
							<td><?= $d->kode.$d->no?></td>							
							<td class="thide">
								<?php  
									if($d->status == 0){
										echo 'Dalam Antrian';
									} else if($d->status == 1){
										echo 'Saatnya ke  '.$d->loket;									
										echo '<input type="hidden" value="'.$d->id.'" name="pname[]">';
									}
								?>
							</td>
							<td class="thide"><?= $d->nama?></td>
							<td class="thide"><?= $d->nik?></td>
							<td class="thide"><?= $d->group?></td>							
						</tr>