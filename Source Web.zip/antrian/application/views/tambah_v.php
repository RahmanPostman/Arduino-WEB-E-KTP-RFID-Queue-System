			<form role="form" method="post" >
					  <div class="form-group">
						<label>NIK:</label>
						<input name="nik" type="text" class="form-control radius-3 margin-b-10" id="email" required>
					  </div>
					  <div class="form-group">
						<label>Nama:</label>
						<input name="nama" type="text" class="form-control radius-3 margin-b-10" id="pwd" required>
					  </div>						  			  					 
					  <div class="form-group">
						<label>ID KTP:</label>
						<input name="idktp" type="text" class="form-control radius-3 margin-b-10" id="pwd">
					  </div>					  
					  
					  <div class="form-group">
						<label>Antrian Untuk:</label>
						<select name="group" >
							<?php foreach($group as $d){ ?>
							<option value="<?=$d->idgroup?>"><?=$d->group?></option>
							<?php } ?>
						</select>						
					  </div>			
					  
					  <button type="submit" name="tambah" value="submit" class="btn-green-brd btn-base-animate-to-top btn-base-sm radius-7">Masuk
                        <span class="btn-base-element-md"><i class="btn-base-element-icon fa fa-users"></i></span>
					   </button>
					  <!-- <a href="<?= base_url('auth/register')?>"><button type="button" name="masuk" value="masuk" class="btn-blue-brd btn-base-animate-to-top btn-base-sm radius-7">Daftar
                        <span class="btn-base-element-md"><i class="btn-base-element-icon fa fa-users"></i></span>
					   </button></a> -->
				</form>