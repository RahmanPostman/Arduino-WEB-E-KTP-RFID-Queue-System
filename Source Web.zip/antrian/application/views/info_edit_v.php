<?php include 'header.php'; ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Info</h1>
            <ol class="breadcrumb">
              <li><a href="<?=base_url();?>dashboard">Dashboard</a></li>
              <li><a href="">Info</a></li>
            </ol>
            <?php if($alert=='success'){ ?>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Success
            </div>
            <?php } ?>

            <?php if($alert=='failed'){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Failed
            </div>
            <?php } ?>
			
			<?php if($error!=''){ ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?=$error;?>
            </div>
            <?php } ?>
			
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-12">
            <form class="form-horizontal" method="post" action="<?=base_url();?>info">              
              <div class="form-group">
                <label for="tahun" class="col-lg-2 control-label">Nama</label>
                <div class="col-lg-6">
                  <input value="<?=$data->nama;?>" name="nama" type="text" class="form-control" id="nama_tahun" placeholder="">
                </div>
              </div> 
			  <div class="form-group">    
				<label for="tahun" class="col-lg-2 control-label">Alamat</label>
                <div class="col-lg-6">
					<textarea name="alamat" class="form-control"><?= $data->alamat?></textarea>
                </div>
              </div>   	
			  <div class="form-group">
                <label for="tahun" class="col-lg-2 control-label">No. Telp</label>
                <div class="col-lg-6">
                  <input value="<?=$data->notelp;?>" name="notelp" type="text" class="form-control" id="nama_tahun" placeholder="">
                </div>
              </div> 			  
			  <div class="form-group">
                <label for="tahun" class="col-lg-2 control-label">Email</label>
                <div class="col-lg-6">
                  <input value="<?=$data->email;?>" name="email" type="text" class="form-control" id="nama_tahun" placeholder="">
                </div>
              </div> 
              <div class="form-group">    
				<label for="tahun" class="col-lg-2 control-label">Informasi Umum</label>
                <div class="col-lg-6">
					<textarea name="info" class="form-control"><?= $data->info?></textarea>
                </div>
              </div>   			  
              <div class="form-group">
                <div class="col-lg-2"></div>
                <div class="col-lg-4">
                  <button class="btn btn-primary pull-right" type="submit" name="simpan" value=1>Simpan</button>                  
                </div>
              </div>
            </form>            
          </div>
        </div><!-- /.row -->

      </div><!-- /#page-wrapper -->   
<?php include 'footer.php'; ?>