<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class jenis_m extends MY_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}

	function get_list_jenis(){
		$sql="select * from jenis ORDER BY id asc";
		$q=$this->db->query($sql);
		$data=$q->result();
		$q->free_result();
		return $data;
	}
	
	function get_list_wajib(){
		$sql="select * from jenis WHERE kategori='wajib' ORDER BY id asc";
		$q=$this->db->query($sql);
		$data=$q->result();
		$q->free_result();
		return $data;
	}
	
	function get_data_by_id($id){
		$b = $this->db->query("SELECT * FROM jenis WHERE id=$id");
		$r = $b->row();
		$b->free_result();
		return $r;
	}
	
	function cek_hapus($id){
		$sql="select * from rekening WHERE jenis LIKE '%$id%'";
		$q=$this->db->query($sql);
		$data=$q->num_rows;
		$q->free_result();
		return $data;
	}
	
}

/* End of file  */
/* Location: ./application/models/ */